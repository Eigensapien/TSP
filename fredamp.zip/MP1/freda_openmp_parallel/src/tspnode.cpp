#include <iostream>
#include <string>
#include <vector>
#include <limits>
#include "tspnode.h"

using std::vector;
using std::string;

Node::Node() {
	//initialize all pointers to NULL
	parent = NULL;
	children = {};
	isCompleteCycle = false;
}

Node::~Node() {
	//delete all children
	//root node deletion brings the whole tree with it recursively
	for (unsigned int i=0; i<children.size(); ++i){
		delete children[i];
	}
}

vector < int > Node::get_sequence() {
	//build a vector by jumping from parent to parent
	vector < int > sequence = {index};//C++11 syntax
	Node* curr = parent;
	while (curr != NULL) {
		sequence.push_back(curr->index);
		curr = curr->parent;
	}
	sequence.push_back(index);//complete the cycle
	return sequence;
}