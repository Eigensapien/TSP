#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <sstream>
#include <istream>
#include "tspnode.h"
#include "tspsolver.h"

using std::vector;
using std::string;
using std::cout;
using std::cin;
using std::endl;
using std::ifstream;
using std::ofstream;
using std::getline;


TSPSolver::TSPSolver() {
	root = NULL;
	bestDistance = std::numeric_limits<float>::max();
	bestSequence = {};
}

TSPSolver::~TSPSolver() {
	//need to delete the tree, fortunately the destructor will delete children recursively
	if (root != NULL) {
		delete root;
	}
}

bool TSPSolver::import_matrix_from_csv(string filename) {
	//just does what the name implies, imports to adjacencyMatrix
	//adjacencyMatrix should be symmetric and use -1 to represent infinities
	//function returns a bool indicating success or failure
	
	ifstream ifs (filename.c_str()); //open the file
	
	if (!ifs) {//if file cannot be opened
		if ( ifs.is_open() ) { ifs.close(); };
		cout << "Error: cannot open file." << endl;
		return false;
	}
	
	cout << "Importing data from " << filename << " . . ." << endl;
	
	//set-up parsing temps
	string currLine;
	string currEntry;
	vector < float > currRow;
	
	//read each line
	adjacencyMatrix = {};
	while (getline(ifs, currLine)) {
		currRow = {};
		//using stringstream and stof to parse from csv strings to floats
		std::stringstream data(currLine);
		while (getline(data, currEntry, ',')) {
			currRow.push_back(std::stof(currEntry));
		}
		//place that row into the matrix
		adjacencyMatrix.push_back(currRow);
	}
	
	//make sure the matrix is square
	if (adjacencyMatrix.size() != adjacencyMatrix[0].size()) {
		cout << "Error: provided adjacency matrix not square" << endl;
		return false;
	}
	
	return true;
}

bool TSPSolver::output_soln_to_csv(string filename) {
	//simply outputs the solution to a file, overwriting its contents
	//returns a bool indicating success or failure
	
	//check that bestdistance != max to make sure solve() has been called successfully
	if (bestDistance == std::numeric_limits<float>::max() ) {
		cout << "Error: solution has not been found. Has solve() been called yet?" << endl;
		return false;
	}
	
	//open the file
	ofstream ofs ( filename.c_str() );
	if (!ofs) {
		if ( ofs.is_open() ) { ofs.close(); };
		cout << "Error: cannot open output file." << endl;
		return false;
	}
	
	//save sequence to file
	for (unsigned int i=0; i<bestSequence.size(); ++i) {
		ofs << bestSequence[i] << ",";
	}
	//save distance to file
	ofs << endl << bestDistance;
	
	return true;
}

float TSPSolver::get_soln_dist(vector < int > solution) {
	//take input vector and go a full cycle to get distance
	float tempsum = 0;
#pragma omp parallel for
	for (unsigned int i=1; i<solution.size(); ++i){
		tempsum += adjacencyMatrix[solution[i-1]][solution[i]];
	}
	return tempsum;
}

vector < int > TSPSolver::solve() {
	//this is the primary user-level function for solving
	//it essentially constructs the root node, then calls grow() on it
	root = new Node;
	root->reducedCostMatrix = adjacencyMatrix;
	root->index = 0;
	root->bound = 0;
	root->distance = 0;
	grow(root);
	return bestSequence;
}

void TSPSolver::grow(Node* meristem) {
	//This function takes a node, branches it to all possible children, then recursively calls itself on viable children
	
	//check for a completed cycle to stop the recursion
	if (meristem->isCompleteCycle) {
		if (meristem->distance < bestDistance) {
			bestDistance = meristem->distance;
			bestSequence = meristem->get_sequence();
		}
	}
	else {
		branch(meristem);//branch must result in sorted children
		//note: do not parallelize this loop since the ordering is important
		//need smallest bound to biggest bound for depth-first along min-bound path
		for (unsigned int i=0; i<meristem->children.size(); ++i) {
			if (meristem->children[i]->bound < bestDistance) {
				grow(meristem->children[i]);//recursive growth on viable branches
			}
			else {//lower bound exceeds best known solution
				break;//remaining child branches cannot contain solution
			}
		}
	}
}

void TSPSolver::branch(Node* meristem) {
	//This function performs the branching along with calling the function to place bounds.
	//As this branching is done, the children are sorted via insertion sort.
	//1. find and create right number of children
	//2. pass along information from parent
	//3. place bounds on children
	//4. sort children
	
	//The loop checks all the relevant entries to see if a path exists
	//note: do not parallelize this loop since it expands a vector (race condition)
	for (unsigned int i=0; i<meristem->reducedCostMatrix[meristem->index].size(); ++i) {
		//the if ignores "infinity" as represented by negatives
		if (meristem->reducedCostMatrix[meristem->index][i] >= 0) {
			//create the new child and feed it data from the parent so it can grow strong
			Node* infant = new Node;
			infant->parent = meristem;
			infant->index = i;
			infant->reducedCostMatrix = meristem->reducedCostMatrix;
			infant->bound = meristem->bound;
			infant->distance = meristem->distance + adjacencyMatrix[meristem->index][i];
			//calculate the bounds on the infant and produce the RCM
			bound(infant);
			//insertion sort for organized children
			unsigned int j = 0;//loop index
			while (true) {
				if (j >= meristem->children.size()) {
					//if we reach the end, place the child there
					meristem->children.push_back(infant);
					break;
				}
				if (meristem->children[j]->bound > infant->bound) {
					//we have found the correct placement
					meristem->children.insert(meristem->children.begin()+j, infant);
					break;
				}
				++j;
			}
		}
	}
}

void TSPSolver::bound(Node* meristem) {
	/*
	takes a pointer to a node, reduces the matrix and changes bound accordingly
	node should have been previously created with RCM and bound of parent
	ie. children should be created as clones of parent, then have bound() called on them
	This section of the code makes up the bulk of the actual computation.
	The loops for row reduction and column reduction are parallelized with openmp for a significant speedup.
	*/
	
	//set infinities in the RCM to prevent looping back to previously visited nodes
	if (meristem->parent != NULL) {
#pragma omp parallel for
		for (unsigned int i=0; i<meristem->reducedCostMatrix[0].size(); ++i) {
			meristem->reducedCostMatrix[meristem->parent->index][i] = -1;
			meristem->reducedCostMatrix[i][meristem->parent->index] = -1;
			meristem->reducedCostMatrix[i][meristem->index] = -1;
		}
		meristem->reducedCostMatrix[meristem->index][meristem->parent->index] = -1;
	}
	meristem->isCompleteCycle = true;//flag only survives as true if all entries are "infinite"
	//reduce rows
#pragma omp parallel for
	for (unsigned int i=0; i<meristem->reducedCostMatrix.size(); ++i) {
		//find minimum element in row
		float min = std::numeric_limits<float>::max();
		for (unsigned int j=0; j<meristem->reducedCostMatrix[i].size(); ++j) {
			if (meristem->reducedCostMatrix[i][j] < min && meristem->reducedCostMatrix[i][j]>=0) {
				min = meristem->reducedCostMatrix[i][j];
			}
		}
		//reduce all elements by minimum, ignore if minimum was infinity
		if (min != std::numeric_limits<float>::max()) {
			meristem->isCompleteCycle = false;//non-infinite entry, not full cycle
			for (unsigned int j=0; j<meristem->reducedCostMatrix[i].size(); ++j) {
				meristem->reducedCostMatrix[i][j] -= min;
			}
			meristem->bound += min;
		}
	}
	//reduce columns
#pragma omp parallel for
	for (unsigned int j=0; j<meristem->reducedCostMatrix[0].size(); ++j) {
		//find minimum element in column
		float min = std::numeric_limits<float>::max();
		for (unsigned int i=0; i<meristem->reducedCostMatrix.size(); ++i) {
			if (meristem->reducedCostMatrix[i][j] < min && meristem->reducedCostMatrix[i][j]>=0) {
				min = meristem->reducedCostMatrix[i][j];
			}
		}
		//reduce all elements by minimum
		if (min != std::numeric_limits<float>::max()) {
			meristem->isCompleteCycle = false;//non-infinite entry, not full cycle
			for (unsigned int i=0; i<meristem->reducedCostMatrix.size(); ++i) {
			meristem->reducedCostMatrix[i][j] -= min;
			}
			meristem->bound += min;
		}
	}
}