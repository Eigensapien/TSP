#ifndef TSPNODE_H
#define TSPNODE_H

#include <iostream>
#include <string>
#include <vector>
#include <limits>

using std::string;
using std::vector;

class Node {
	/*
	This class defines a node for a tree structure. Each node contains pointers to its children and its parent.
	Data relevant to the TSP is stored as well along with a flag for leaf nodes (complete cycles).
	A single member function allows for a sequence to be obtained from a leaf by traversal toward the root.
	*/
	
	public:
	
		//constructor+destructor
		Node();
		~Node();
	
		//storage of relevant data
		vector < vector <float> > reducedCostMatrix;
		int index;
		float bound;
		float distance;
	
		//pointers for tree structure
		vector < Node* > children;
		Node* parent;
	
		//flag for completed cycles
		bool isCompleteCycle;
	
		//misc. functions
		vector < int > get_sequence();
};

#endif