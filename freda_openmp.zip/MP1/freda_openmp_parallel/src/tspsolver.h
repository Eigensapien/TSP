#ifndef TSPSOLVER_H
#define TSPSOLVER_H

#include <iostream>
#include <fstream>
#include <vector>
#include <string>

using std::vector;
using std::string;

class TSPSolver {
	/*
	This class serves as a solver for the TSP.
	The branch and bound method is used to generate solutions from an adjacency matrix.
	-1 is used to represent infinite in this matrix.
	The growth is done recursively in what is effectively a depth-first search that prioritizes branches with the lowest bounds.
	The solution obtained is exact, as the only unexplored branches are those that have been proven to not contain the ideal solution.
	To use:
		import the matrix from the file
		call solve() to generate a solution
		use the output function to save the solution
	note: "meristem" is the botanical term for undifferentiated cells at the end of a growing branch.
	*/
	
	public:
	
		//constructor+destructor
		TSPSolver();
		~TSPSolver();
	
		//adjacency matrix and solution space tree
		Node* root;
		vector < vector <float> > adjacencyMatrix;
	
		//IO functions
		bool import_matrix_from_csv(string filename);
		bool output_soln_to_csv(string filename);
	
		//misc. functions
		float get_soln_dist(vector < int > solution);

		//master function
		vector < int > solve();
	
	private:
	
		//helpers for solve()
		void grow(Node* meristem);
		void branch(Node* meristem);
		void bound(Node* meristem);
	
		//best solution found for comparison
		float bestDistance;
		vector < int > bestSequence;
};

#endif