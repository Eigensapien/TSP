#include <omp.h>
#include <iostream>
#include <string>
#include "tspnode.h"
#include "tspsolver.h"

using std::cout;
using std::cin;
using std::endl;
using std::string;
using std::vector;

int main(int argc, char** argv) {
	
	//check for correct usage
	if (argc < 2) {
		cout << "Error: missing argument for adjacency matrix csv file" << endl;
		return 1;
	}
	if (argc > 2) {
		cout << "Warning: only first argument (filename) is used" << endl;
	}
	
	//attempt to import the file
	string filename(argv[1]);
	TSPSolver solver;
	if (!solver.import_matrix_from_csv(filename)) {
		cout << "Error: file import failed. Aborting." << endl;
		return 1;
	}
	
	//generate solution and time
	cout << "Generating TSP solution..." << endl;
	double wallTime = omp_get_wtime();
	vector < int > solution = solver.solve();
	wallTime = omp_get_wtime() - wallTime;
	
	//display the results
	cout << "Solution: ";
	for (unsigned int i=0; i<solution.size(); ++i) {
		cout << solution[i] << "  ";
	}
	cout << endl << "Distance: " << solver.get_soln_dist(solution) << endl;
	cout << "Time taken: " << wallTime << endl;
	cout << "Maximum threads: " << omp_get_max_threads() << endl;
	
	//output to file
	bool success = false;
	while (!success) {
		cout << "Where should output be saved (overwrite)?:" << endl;
		cin >> filename;
		success = solver.output_soln_to_csv(filename);
		if (!success) {
			cout << "Error: could not save to file." << endl;
			cout << "Try again? (y/N): " << endl;
			cin >> filename;//reduce, reuse, recycle
			if (filename.compare("y") != 0) {
				success = true;//exit loop
			}
		}
	}
}