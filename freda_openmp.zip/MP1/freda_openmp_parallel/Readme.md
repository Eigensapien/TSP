Traveling Salesman Problem by Branch and Bound with OpenMP
Created by Eric Freda as a project for CS 540 (HPC) at Chapman University

All code written from scratch by Eric Freda

Branch and Bound techniques for TSP developed in the late 1950s by Bock, Croes, Eastman, Rossman, and Twery

"The traveling salesman problem: a computational study" by Applegate, Bixby, Chvatal, and Cook (2006) published by Princeton University Press used as a general reference.

To compile:
Run "make" in either the outer directory or the /src/ directory.
This program was developed for C++11.
Calling in the outer directory will move the executable file to the outer directory.
"make clean" removes all ".o" files.
"make cleaner" removes the executable file.

To run:
The program should be called with one additonal argument for the data file.
This file should contain the adjacency matrix as comma-separated values.
Use "-1" to represent infinity for nodes that are not connected, including the diagonal.
The adjacency matrix should be symmetric (it is possible that an asymmetric matrix will work, but this has not been tested).
For examples, look in /data/

Be warned: while branch and bound techniques are better than a brute search, they are still quite limited. On a virtual machine with 2 cores and 2gb of RAM the program was able to handle approximately 12 cities before crashing. Do not feed this program a large TSP unless you are willing to deal with the consequences.